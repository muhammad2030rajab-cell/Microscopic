import {
  createFileRoute,
  Navigate,
  Link,
  Outlet,
  redirect,
  useRouter,
  useRouterState,
} from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import {
  BarChart3,
  Boxes,
  CheckCircle2,
  Hourglass,
  ChevronLeft,
  CircleHelp,
  ClipboardList,
  FilePlus2,
  FileText,
  Files,
  FlaskConical,
  Settings2,
  Stethoscope,
  UsersRound,
  ScrollText,
  Wallet,
  TriangleAlert,
  UserRoundSearch,
  Users,
} from "lucide-react";

import { AppShell } from "@/components/layout/app-shell";
import { UserButton, useCurrentUserState } from "@/lib/auth/gates";
import { getCurrentAccess, getCurrentLab, getLabDashboardStats, getLabDashboardCharts, type LabDashboardCharts, type LabProfileData } from "@/lib/lab-access";
import { FieldOfView } from "@/components/brand/field-of-view";
import { CategoryDonut, WeeklyBars } from "@/components/charts/dashboard-charts";
import { InventoryAlerts } from "@/components/inventory-alerts";
import { BackupAlert, BillingAlerts } from "@/components/lab-alerts";
import { loadLocalDashboard } from "@/lib/sync-engine/offline-fallback";
import { requestAllOfflinePages } from "@/lib/offline/sync";
import { getRecentLabReports, type RecentReport } from "@/lib/lab-reports";
import { getCurrentLabPermissions, getJoinOverview, type LabPermissions } from "@/lib/lab-users";
import { formatAge } from "@/lib/age";
import { presetReportFilters, type ReportFilters } from "@/lib/reports-filters";
import { reportStatusClasses, reportStatusLabels } from "@/lib/report-workflow";
import { cn, formatListDate } from "@/lib/utils";

export const Route = createFileRoute("/lab")({
  // The data loads in the browser (never in the server-rendered HTML): the saved offline copy of this page
  // then holds no patient data, and with no connection the loader answers from the device copy instead.
  ssr: false,
  loader: async () => {
    try {
      const [lab, stats, access, recent, charts] = await Promise.all([
        getCurrentLab(),
        getLabDashboardStats(),
        getCurrentLabPermissions(),
        // Not everyone may view reports; the home screen must still load for them.
        getRecentLabReports().catch(() => [] as RecentReport[]),
        getLabDashboardCharts().catch(() => null as LabDashboardCharts | null),
      ]);

      return { lab, stats, permissions: access.permissions, recent, charts, loadFailed: false, offline: false };
    } catch (error) {
      // No connection: the home screen from the device copy (counters, latest reports, lab header).
      if (typeof window !== "undefined") {
        const local = await loadLocalDashboard<LabProfileData>(error);
        if (local) {
          return { lab: local.lab, stats: local.stats, permissions: local.permissions as LabPermissions, recent: local.recent, charts: null as LabDashboardCharts | null, loadFailed: false, offline: true };
        }
      }
      // لو الحساب اتوقف وهو داخل، نحوّله لصفحة الدخول (فيها رسالة التواصل مع المدير)
      const access = await getCurrentAccess().catch(() => null);
      if (access?.type === "suspended" || access?.type === "pending") throw redirect({ to: "/login" });
      // حساب المدير ملوش معمل: نوديه للوحته بدل ما نرجّعه لتسجيل الدخول.
      if (access?.type === "admin") throw redirect({ to: "/admin" });

      return {
        lab: null,
        // الحساب سليم ومرتبط بمعمل لكن التحميل فشل: نعرض رسالة بدل دايرة login <-> lab.
        loadFailed: access?.type === "lab",
        offline: false,
        stats: {
          patients: 0,
          reportsToday: 0,
          pendingReview: 0,
          approved: 0,
          critical: 0,
        },
        permissions: {} as LabPermissions,
        recent: [] as RecentReport[],
        charts: null as LabDashboardCharts | null,
      };
    }
  },

  component: LabDashboard,
});

function LabDashboard() {
  const pathname = useRouterState({
    select: (state) => state.location.pathname,
  });

  const { user, isPending } = useCurrentUserState();

  const { lab, stats, permissions, recent, charts, loadFailed, offline } = Route.useLoaderData();
  const router = useRouter();

  // For managers: how many people asked to join with the join code and wait for an answer.
  // (Not a manager, or no connection: the call fails and nothing is shown.)
  const [joinPending, setJoinPending] = useState(0);
  useEffect(() => {
    if (!lab || offline || loadFailed) return;
    let alive = true;
    getJoinOverview()
      .then((o) => alive && setJoinPending(o.pending))
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [lab, offline, loadFailed]);

  // Signed in and loaded: keep the other offline screens ready on this device.
  useEffect(() => {
    if (lab && !loadFailed && navigator.onLine) requestAllOfflinePages();
  }, [lab, loadFailed]);

  /*
   * Child routes such as /lab/setup are rendered through Outlet.
   */
  if (pathname !== "/lab") {
    return <Outlet />;
  }

  if (isPending && !offline) {
    return (
      <main className="grid min-h-screen place-items-center bg-paper">
        جارٍ التحقق…
      </main>
    );
  }

  if (loadFailed && user) {
    return (
      <main className="grid min-h-screen place-items-center bg-paper px-4 text-center">
        <div className="max-w-sm space-y-4">
          <p className="text-lg font-semibold">تعذّر تحميل بيانات المعمل</p>
          <p className="text-sm text-muted">
            حصلت مشكلة مؤقتة في الاتصال بالسيرفر. تأكد من الإنترنت وحاول تاني.
          </p>
          <button
            type="button"
            className="rounded-lg bg-ink px-4 py-2 text-sm text-paper"
            onClick={() => void router.invalidate()}
          >
            إعادة المحاولة
          </button>
        </div>
      </main>
    );
  }

  // With no connection the sign-in session cannot be re-checked (it is read from the server), so a home
  // screen answered from the device copy is allowed without it. That copy is only ever used after a network
  // failure, never after the server rejected the session, and it is wiped on sign-out.
  if (!lab || (!user && !offline)) {
    return <Navigate to="/login" replace />;
  }

  if (!lab.is_profile_complete) {
    return <Navigate to="/lab/setup" />;
  }

  const greetingName = lab.doctor_name
    ? `د. ${lab.doctor_name}`
    : lab.lab_name;

  const canView = permissions["reports.view"] === true;

  const todayLabel = new Intl.DateTimeFormat("ar-EG", {
    weekday: "long",
    day: "numeric",
    month: "long",
    timeZone: "Africa/Cairo",
  }).format(new Date());

  return (
    <AppShell>
      <header className="mb-4 flex items-center justify-between gap-3 lg:hidden">
        <div className="min-w-0">
          <p className="text-[11px] uppercase tracking-[0.2em] text-muted">
            Medical Laboratory
          </p>

          <h1 className="mt-0.5 truncate font-display text-lg font-semibold">
            {lab.lab_name}
          </h1>
        </div>

        <UserButton />
      </header>

      {/* Greeting + the one thing people open the app to do */}
      <section className="app-hero relative overflow-hidden rounded-3xl p-6 text-paper sm:p-8">
        <FieldOfView className="app-hero-art" />

        <div className="relative z-10">
          <p className="text-sm text-paper/65">{todayLabel}</p>

          <h2 className="mt-1.5 font-display text-2xl font-bold sm:text-3xl">
            أهلاً، {greetingName}
          </h2>

          <p className="mt-2 hidden max-w-sm text-sm leading-7 text-paper/70 sm:block">
            دقة في التحليل .. ثقة في النتيجة
          </p>

          {permissions["reports.create"] ? (
            <Link
              to="/new"
              className="mt-5 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-paper text-base font-bold text-ink shadow-[0_14px_28px_-14px_rgb(0_0_0/0.6)] transition hover:bg-white active:scale-[0.99] sm:w-auto sm:px-8"
            >
              <FilePlus2 className="size-5" />
              تقرير جديد
            </Link>
          ) : null}
        </div>
      </section>

      {/* Today at a glance — each card opens the archive already filtered */}
      {joinPending > 0 ? (
        <Link
          to="/team"
          role="status"
          className="mt-4 flex items-center justify-between gap-3 rounded-2xl border border-teal/40 bg-teal/10 p-4 transition-colors hover:bg-teal/15"
        >
          <span className="flex items-center gap-3">
            <span className="relative grid size-10 place-items-center rounded-full bg-teal text-paper">
              <span className="absolute inset-0 animate-ping rounded-full bg-teal/40" aria-hidden />
              <span className="relative text-sm font-bold">{joinPending}</span>
            </span>
            <span>
              <span className="block text-sm font-semibold">{joinPending === 1 ? "طلب انضمام جديد" : "طلبات انضمام جديدة"}</span>
              <span className="block text-xs text-muted">مستنيين موافقتك. اضغط عشان تراجعهم</span>
            </span>
          </span>
          <span className="text-sm font-medium text-teal">مراجعة ←</span>
        </Link>
      ) : null}

      <section aria-label="ملخص اليوم" className="mt-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatLink
          to="/patients"
          label="إجمالي المرضى"
          value={stats.patients}
          icon={<Users className="size-5" />}
          iconClass="bg-teal/10 text-teal"
        />

        <StatLink
          to="/reports"
          preset={{ period: "today" }}
          disabled={!canView}
          label="تقارير اليوم"
          value={stats.reportsToday}
          icon={<FileText className="size-5" />}
          iconClass="bg-ok/10 text-ok"
        />

        <StatLink
          to="/reports"
          preset={{ status: "pending_review" }}
          disabled={!canView}
          label="بانتظار المراجعة"
          value={stats.pendingReview}
          icon={<Hourglass className="size-5" />}
          iconClass="bg-low-bg text-low"
        />

        <StatLink
          to="/reports"
          preset={{ status: "all" }}
          disabled={!canView}
          label="إجمالي التقارير"
          value={stats.approved}
          icon={<CheckCircle2 className="size-5" />}
          iconClass="bg-accent/10 text-accent"
        />
      </section>

      {stats.critical > 0 && canView ? (
        <Link
          to="/reports"
          onClick={() => presetReportFilters({ period: "today", onlyCritical: true })}
          className="mt-3 flex items-center gap-2 rounded-xl border border-high/40 bg-high-bg/50 px-4 py-3 text-sm font-medium text-high"
        >
          <TriangleAlert className="size-4" />
          {stats.critical} تقرير حرج اليوم، اضغط للمراجعة
        </Link>
      ) : null}

      {charts && canView ? (
        <section aria-label="إحصائيات" className="mt-4 grid gap-3 lg:grid-cols-5">
          <div className="app-card p-5 lg:col-span-3">
            <h2 className="app-section-title mb-3">إحصائيات التحاليل</h2>
            <p className="-mt-2 mb-3 text-[11px] text-muted">عدد التقارير في آخر 7 أيام</p>
            <WeeklyBars data={charts.daily} />
          </div>

          <div className="app-card p-5 lg:col-span-2">
            <h2 className="app-section-title mb-3">أنواع التحاليل</h2>
            {charts.categories.length === 0 ? (
              <p className="py-8 text-center text-xs text-muted">لا توجد بيانات كافية بعد.</p>
            ) : (
              <CategoryDonut data={charts.categories} />
            )}
          </div>
        </section>
      ) : null}

      {/* Latest reports */}
      {canView ? (
        <section className="mt-5">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="app-section-title">أحدث الحالات</h2>
            <Link
              to="/reports"
              onClick={() => presetReportFilters({})}
              className="inline-flex min-h-9 items-center gap-1 text-sm text-teal"
            >
              كل التقارير
              <ChevronLeft className="size-4" />
            </Link>
          </div>

          {recent.length === 0 ? (
            <p className="rounded-xl border border-dashed border-line px-4 py-8 text-center text-sm text-muted">
              لا توجد تقارير بعد. ابدأ بإنشاء أول تقرير.
            </p>
          ) : (
            <ul className="app-card divide-y divide-line overflow-hidden">
              {recent.map((r) => (
                <li key={r.id}>
                  <Link
                    to="/reports/$id"
                    params={{ id: r.id }}
                    className="flex items-center gap-3 px-4 py-3 hover:bg-paper"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{r.patientName}</p>
                      <p className="mt-0.5 text-xs text-muted">
                        {formatAge("ar", r.age, r.ageUnit)} · {r.gender} · {formatListDate(r.createdAt)}
                      </p>
                    </div>

                    {r.criticalCount > 0 ? (
                      <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-high-bg px-2 py-1 text-[11px] font-medium text-high">
                        <TriangleAlert className="size-3" />
                        حرج
                      </span>
                    ) : r.flaggedCount > 0 ? (
                      <span className="shrink-0 text-[11px] text-high">{r.flaggedCount} علامة</span>
                    ) : null}

                    <span
                      className={cn(
                        "shrink-0 rounded-full px-2 py-1 text-[11px]",
                        reportStatusClasses[r.status],
                      )}
                    >
                      {reportStatusLabels[r.status]}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>
      ) : null}

      {lab.role === "owner" || permissions["inventory.manage"] === true ? <InventoryAlerts /> : null}
      {lab.role === "owner" || permissions["billing.manage"] === true ? <BillingAlerts /> : null}
      {lab.role === "owner" ? <BackupAlert /> : null}

      {/* Everything else: small tiles, so they do not push the useful parts off-screen */}
      <section aria-label="اختصارات" className="mt-5 grid grid-cols-3 gap-2.5 sm:grid-cols-6">
        <Shortcut to="/reports" icon={<Files />} label="الأرشيف" onClick={() => presetReportFilters({})} />
        <Shortcut to="/patients" icon={<UserRoundSearch />} label="المرضى" />
        <Shortcut to="/catalog" icon={<ClipboardList />} label="دليل التحاليل" />
        <Shortcut to="/contacts" icon={<Stethoscope />} label="الأطباء والعملاء" />
        <Shortcut to="/methods" icon={<FlaskConical />} label="كيف يتم التحليل" />
        <Shortcut to="/analytics" icon={<BarChart3 />} label="الإحصائيات" />
        {lab.role === "owner" || permissions["inventory.manage"] === true ? <Shortcut to="/inventory" icon={<Boxes />} label="الأجهزة والمستلزمات" /> : null}
        {lab.role === "owner" || permissions["users.manage"] === true ? <Shortcut to="/audit" icon={<ScrollText />} label="سجل العمليات" /> : null}
        {lab.role === "owner" || permissions["billing.manage"] === true ? <Shortcut to="/billing" icon={<Wallet />} label="الحسابات" /> : null}
        {lab.role === "owner" || permissions["users.manage"] === true ? <Shortcut to="/team" icon={<UsersRound />} label="الفريق وكود الانضمام" /> : null}
        {lab.role === "owner" ? <Shortcut to="/settings" icon={<Settings2 />} label="الإعدادات" /> : null}
        <Shortcut to="/help" icon={<CircleHelp />} label="مساعدة" />
      </section>
    </AppShell>
  );
}

function StatLink({
  to,
  preset,
  label,
  value,
  icon,
  iconClass,
  tone,
  disabled = false,
  className,
}: {
  to: string;
  preset?: Partial<ReportFilters>;
  label: string;
  value: number;
  icon: ReactNode;
  iconClass?: string;
  tone?: "warn" | "danger";
  disabled?: boolean;
  className?: string;
}) {
  const body = (
    <div className="flex items-center gap-3">
      <span className={cn("grid size-12 shrink-0 place-items-center rounded-2xl", iconClass ?? "bg-teal/10 text-teal")}>
        {icon}
      </span>
      <span className="min-w-0">
        <span className="block font-display text-3xl font-bold leading-none tabular-nums">{value}</span>
        <span className="mt-1 block truncate text-xs text-muted">{label}</span>
      </span>
    </div>
  );

  const box = cn(
    "app-card block p-4",
    tone === "danger" && "border-high/40 bg-high-bg/40",
    tone === "warn" && "border-amber-300",
    className,
  );

  if (disabled) return <div className={box}>{body}</div>;

  return (
    <Link
      to={to}
      onClick={preset ? () => presetReportFilters(preset) : undefined}
      className={cn(box, "active:scale-[0.99]")}
    >
      {body}
    </Link>
  );
}

function Shortcut({
  to,
  icon,
  label,
  onClick,
}: {
  to: string;
  icon: ReactNode;
  label: string;
  onClick?: () => void;
}) {
  return (
    <Link
      to={to}
      onClick={onClick}
      className="app-card flex min-h-20 flex-col items-center justify-center gap-1.5 p-2 text-center text-xs font-semibold text-ink-soft active:scale-[0.98] [&_svg]:size-5 [&_svg]:text-teal"
    >
      {icon}
      {label}
    </Link>
  );
}
